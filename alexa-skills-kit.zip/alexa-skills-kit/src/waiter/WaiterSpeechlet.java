/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
 */
package waiter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazon.speech.slu.Intent;
import com.amazon.speech.slu.Slot;
import com.amazon.speech.speechlet.IntentRequest;
import com.amazon.speech.speechlet.LaunchRequest;
import com.amazon.speech.speechlet.Session;
import com.amazon.speech.speechlet.SessionEndedRequest;
import com.amazon.speech.speechlet.SessionStartedRequest;
import com.amazon.speech.speechlet.Speechlet;
import com.amazon.speech.speechlet.SpeechletException;
import com.amazon.speech.speechlet.SpeechletResponse;
import com.amazon.speech.ui.PlainTextOutputSpeech;
import com.amazon.speech.ui.Reprompt;
import com.amazon.speech.ui.SimpleCard;

/**
 * This sample shows how to create a simple speechlet for handling speechlet
 * requests.
 */
public class WaiterSpeechlet implements Speechlet {
    
    Boolean odd = false;
    ArrayList<Food> orderlist;
    int listSize = 0;
    String menu, price;
    
    final int RESTAURANT_ID = 12;
    final int ECHO_ID = -2;
    
    private static final Logger log = LoggerFactory
            .getLogger(WaiterSpeechlet.class);
    
    @Override
    public void onSessionStarted(final SessionStartedRequest request,
            final Session session) throws SpeechletException {
        log.info("onSessionStarted requestId={}, sessionId={}",
                request.getRequestId(), session.getSessionId());
        // any initialization logic goes here
        orderlist = new ArrayList<Food>();
        listSize = 0;
    }
    
    @Override
    public SpeechletResponse onLaunch(final LaunchRequest request,
            final Session session) throws SpeechletException {
        log.info("onLaunch requestId={}, sessionId={}", request.getRequestId(),
                session.getSessionId());
        return getWelcomeResponse();
    }
    
    @Override
    public SpeechletResponse onIntent(final IntentRequest request,
            final Session session) throws SpeechletException {
        log.info("onIntent requestId={}, sessionId={}", request.getRequestId(),
                session.getSessionId());
        
        Intent intent = request.getIntent();
        String intentName = (intent != null) ? intent.getName() : null;
        
        if ("OrderFood".equals(intentName)) {
            return startOrder(intent);
        } else if ("FinishOrder".equals(intentName)) {
            return finish();
        } else if ("AMAZON.HelpIntent".equals(intentName)) {
            return getHelpResponse();
        } else if ("AMAZON.StopIntent".equals(intentName) || "AMAZON.CancelIntent".equals(intentName)) {
            PlainTextOutputSpeech outputSpeech = new PlainTextOutputSpeech();
            outputSpeech.setText("Alright, the order is cancelled");
            try {
                webCall("finishedfinished", "2");
            } catch (ClientProtocolException e) {  
                e.printStackTrace();
            } catch (IOException e) {
                
                e.printStackTrace();
            }
            return SpeechletResponse.newTellResponse(outputSpeech);
        } else {
            throw new SpeechletException("Invalid Intent");
        }
    }
    
    @Override
    public void onSessionEnded(final SessionEndedRequest request,
            final Session session) throws SpeechletException {
        log.info("onSessionEnded requestId={}, sessionId={}",
                request.getRequestId(), session.getSessionId());
        // any cleanup logic goes here
    }
    
    /**
     * Creates and returns a {@code SpeechletResponse} with a welcome message.
     *
     * @return SpeechletResponse spoken and visual response for the given intent
     * @throws IOException
     * @throws ClientProtocolException
     */
    private SpeechletResponse getWelcomeResponse() {
        menu = "";
        String speechText = "Welcome! My name is Chives. What would you like to eat today?";
        try {
            
            HttpClient httpclient = HttpClients.createDefault();
            HttpGet httpget = new HttpGet("http://waiter.bleak.io/menu/"
                    + RESTAURANT_ID);
            // Request parameters and other properties.
            
            // Execute and get the response.
            HttpResponse response = httpclient.execute(httpget);
            menu = EntityUtils.toString(response.getEntity());
        } catch (Throwable t) {
            t.printStackTrace();
        }
        // Create the Simple card content.
        SimpleCard card = new SimpleCard();
        card.setTitle("HelloWorld");
        card.setContent(speechText);
        
        // Create the plain text output.
        PlainTextOutputSpeech speech = new PlainTextOutputSpeech();
        speech.setText(speechText);
        
        // Create reprompt
        Reprompt reprompt = new Reprompt();
        reprompt.setOutputSpeech(speech);
        
        return SpeechletResponse.newAskResponse(speech, reprompt, card);
    }
    
    private SpeechletResponse convo() {
        
        String speechText = "What else would you like to eat?";
        
        // Create the Simple card content.
        SimpleCard card = new SimpleCard();
        card.setTitle("HelloWorld");
        card.setContent(speechText);
        
        // Create the plain text output.
        PlainTextOutputSpeech speech = new PlainTextOutputSpeech();
        speech.setText(speechText);
        
        // Create reprompt
        Reprompt reprompt = new Reprompt();
        reprompt.setOutputSpeech(speech);
        
        return SpeechletResponse.newAskResponse(speech, reprompt, card);
        
    }
    
    /**
     * Creates a {@code SpeechletResponse} for the hello intent.
     *
     * @return SpeechletResponse spoken and visual response for the given intent
     */
    private SpeechletResponse startOrder(Intent intent) {
        
        Slot itemSlot = intent.getSlot("Food");
        String itemName = "Hello world";
        if (itemSlot != null && itemSlot.getValue() != null)
            itemName = itemSlot.getValue();
        
        String speechText = "";
        
        if (!menu.contains(itemName)) {
            speechText = "What you ordered is not on the menu. "; // add to cart
        } else {
            speechText = "You have ordered " + itemName; // add to cart
            
            try {
                webCall(itemName, "0");
            } catch (ClientProtocolException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            Food f = new Food(1, itemName);
            listSize++;
            if (orderlist.contains(f))
                orderlist.get(orderlist.indexOf(f)).quantity++;
            else
                orderlist.add(f);
  
        }
        
        speechText = speechText + ". What else would you like to eat?";
        
        // Create the Simple card content.
        SimpleCard card = new SimpleCard();
        card.setTitle("Order");
        card.setContent(speechText);
        
        // Create the plain text output.
        PlainTextOutputSpeech speech = new PlainTextOutputSpeech();
        speech.setText(speechText);
        
        // Create reprompt
        Reprompt reprompt = new Reprompt();
        reprompt.setOutputSpeech(speech);
        
        return SpeechletResponse.newAskResponse(speech, reprompt, card);
        
        // return SpeechletResponse.newTellResponse(speech, card);
    }
    
    private void webCall(String s, String isFinished)
            throws ClientProtocolException, IOException {
        HttpClient httpclient = HttpClients.createDefault();
        HttpPost httppost = new HttpPost("http://waiter.bleak.io/order");
        httppost.addHeader("item", s);
        httppost.addHeader("Rest-ID", RESTAURANT_ID + "");
        httppost.addHeader("Echo-ID", ECHO_ID + "");
        httppost.addHeader("isFinished", isFinished);
        // Request parameters and other properties.
        List<NameValuePair> params = new ArrayList<NameValuePair>(2);
        params.add(new BasicNameValuePair("item", s));
        params.add(new BasicNameValuePair("Rest-ID", RESTAURANT_ID + ""));
        params.add(new BasicNameValuePair("Echo-ID", ECHO_ID + ""));
        params.add(new BasicNameValuePair("isFinished", isFinished));
        
        httppost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
        
        // Execute and get the response.
        HttpResponse response = httpclient.execute(httppost);
        HttpEntity entity = response.getEntity();
        
        if (entity != null) {
            price = EntityUtils.toString(entity, "UTF-8");
            
        }
    }
    
    private SpeechletResponse finish() {
        
        if (listSize == 0) {
            PlainTextOutputSpeech outputSpeech = new PlainTextOutputSpeech();
            outputSpeech.setText("Goodbye");
            
            return SpeechletResponse.newTellResponse(outputSpeech);
            
        }
        String i = " items";
        if (listSize == 1)
            i = " item";
        
        String speechText = "You have ordered " + listSize + i; // add
                                                                        // to
                                                                        // cart
        
        for (Food s : orderlist)
            speechText = speechText + ", " + s.quantity + " " + s.name;
        
        // Create the Simple card content.
        SimpleCard card = new SimpleCard();
        card.setTitle("Order");
        card.setContent(speechText);
        
        // Create the plain text output.
        PlainTextOutputSpeech speech = new PlainTextOutputSpeech();
        
        try {
            webCall("finishedfinished", "1");
            speechText = speechText + ". Your total cost is "
                    + price.substring(0, price.length() - 3) + " dollars and "
                    + price.substring(price.length() - 2, price.length())
                    + " cents";
        } catch (ClientProtocolException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        speech.setText(speechText);
        
        return SpeechletResponse.newTellResponse(speech, card);
    }
    
    /**
     * Creates a {@code SpeechletResponse} for the help intent.
     *
     * @return SpeechletResponse spoken and visual response for the given intent
     */
    private SpeechletResponse getHelpResponse() {
        String speechText = "Please request an item to order. If it is on the menu, we will make it as soon as possible!";
        
        // Create the Simple card content.
        SimpleCard card = new SimpleCard();
        card.setTitle("HELP");
        card.setContent(speechText);
        
        // Create the plain text output.
        PlainTextOutputSpeech speech = new PlainTextOutputSpeech();
        speech.setText(speechText);
        
        // Create reprompt
        Reprompt reprompt = new Reprompt();
        reprompt.setOutputSpeech(speech);
        
        return SpeechletResponse.newAskResponse(speech, reprompt, card);
    }
    
    public class Food {
        int quantity = 0;
        String name = "";
        
        public Food(int i, String s) {
            quantity = i;
            name = s;
        }
        
        @Override
        public boolean equals(Object obj) {
            if (obj == null) {
                return false;
            }
            if (!Food.class.isAssignableFrom(obj.getClass())) {
                return false;
            }
            final Food other = (Food) obj;
            if ((this.name == null) ? (other.name != null) : !this.name
                    .equals(other.name)) {
                return false;
            }
            return true;
        }
    }
}
